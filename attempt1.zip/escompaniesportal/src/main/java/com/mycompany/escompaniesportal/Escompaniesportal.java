/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.escompaniesportal;

import java.util.Scanner;

/**
 *
 * @author BARBARA ROSMERY
 */
public class Escompaniesportal {

    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("ES Companies Portal - Cashier App");
        System.out.println("=============================="); 
        System.out.print("Input item's name : ");
        String item_name = scn.nextLine();
        System.out.print("Input item's Price [use decimal numbers] : ");
        scn.next();
        Double item_price = scn.nextDouble();
        System.out.print("Input item's quantity [1..20] : ");
        int item_quantity = scn.nextInt();
        System.out.print("Input item's discount [0..50] : ");
        int item_discount = scn.nextInt();
    
        System.out.println("\nES Companies Portal - Invoice");
        System.out.println("==============================");
        System.out.println("Item's name : " + item_name);
        System.out.println("Item's price : " + item_price);
        System.out.println("Item's quantity: " + item_quantity);
        System.out.println("Item's discount : " + item_discount+"%");

        Double total = item_price * item_quantity - item_price * item_quantity * item_discount/100;
        Double totalbulat = (double)Math.round(total * 100) / 100;
        System.out.print("You have to pay $" + totalbulat);
        
        System.out.print("\nInput your money [use decimal numbers] : ");
        scn.next();
        Double your_money = scn.nextDouble();
        
        System.out.print("\nThanks for purchasing!");
        Double kembalianbulat = (double)Math.round((your_money - totalbulat) * 100) / 100;
        System.out.print("\nYour change : $" + kembalianbulat );
    }

    
}
