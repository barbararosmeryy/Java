/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cashierapp2;

import java.util.Scanner;

/**
 *
 * @author BARBARA ROSMERY
 */
public class Cashierapp2 {

    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("ES Companies Portal - Cashier App");
        System.out.println("=============================="); 
        System.out.println("1. Keyboard - $49.99 ");
        System.out.println("2. Mouse - $19.99 ");
        System.out.println("3. Monitor - $99.99 ");
        System.out.println("4. Exit ");
        System.out.print("Choose : ");
        int angka = scn.nextInt();
         
        int quantity;
        double total;
        double money;
        switch (angka) {
            case 1:
                System.out.print("Input quantity [1..20] :  ");
                quantity = scn.nextInt();
                if(quantity <= 20 && quantity >= 1){
                    System.out.println("Item's name : Keyboard");
                    System.out.println("Price : 49.99");
                    System.out.println("Quantity : " + quantity );
                    
                    System.out.println("");
                   total = 49.99 * quantity;
                   total = (double)Math.round(total*100)/100;
                  
                    System.out.println("total :" + total);
                    System.out.print("Input your money [min" + total + "] : ");
                    money = scn.nextDouble();
                    
                  if(money < total ){
                      System.out.println("not enough money");
                      
                  }
                  else{
                      System.out.println("Thanks for purchasing!");
                      System.out.println("Your Change : " + (double)Math.round((money - total)*100)/100);
                      
                      
                  }
                  System.out.println("");
                  System.out.println("Thanks for using this application :D");
                }
                else{
                    System.out.println("Out of the stock!");
                }
                break;
            case 2:
                System.out.print("Input quantity [1..20] :  ");
                quantity = scn.nextInt();
                if(quantity <= 20 && quantity >= 1){
                    System.out.println("Item's name : Mouse ");
                    System.out.println("Price : 19.99");
                    System.out.println("Quantity : " + quantity );
                    
                    System.out.println("");
                   total = 19.99 * quantity;
                   total = (double)Math.round(total*100)/100;
                    System.out.println("total :" + total);
                    System.out.print("Input your money [min" + total + "] : ");
                    money = scn.nextDouble();
                    
                  if(money < total ){
                      System.out.println("not enough money");
                      
                  }
                  else{
                      System.out.println("Thanks for purchasing!");
                      System.out.println("Your Change : " + (double)Math.round((money - total)*100)/100);
                      
                      
                  }
                  System.out.println("");
                  System.out.println("Thanks for using this application :D");
                }
                else{
                    System.out.println("Out of the stock!");
                    
                }
                break;  
            case 3:
                System.out.print("Input quantity [1..20] :  ");
                quantity = scn.nextInt();
                if(quantity <= 20 && quantity >= 1){
                    System.out.println("Item's name : Monitor ");
                    System.out.println("Price : 99.99");
                    System.out.println("Quantity : " + quantity );
                    
                    System.out.println("");
                   total = 99.99 * quantity;
                   total = (double)Math.round(total*100)/100;
                   
                    System.out.println("total :" + total);
                    System.out.print("Input your money [min" + total + "] : ");
                    money = scn.nextDouble();
                    
                  if(money < total ){
                      System.out.println("not enough money");
                      
                  }
                  else{
                      System.out.println("Thanks for purchasing!");
                      System.out.println("Your Change : " + (double)Math.round((money - total)*100)/100);
                      
                      
                  }
                  System.out.println("");
                  System.out.println("Thanks for using this application :D");
                }
                else{
                    System.out.println("Out of the stock!");
                }
                break;
                
            case 4:
                System.exit(0);
                break;
            default:
                System.out.println("== Menu tidak ada ==");
        }
        
       
            
    
        
        
        
    }
}
