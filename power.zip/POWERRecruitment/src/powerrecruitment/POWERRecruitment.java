/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package powerrecruitment;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author BARBARA ROSMERY
 */
public class POWERRecruitment {

    /**
     * @param args the command line arguments
     */
     private static ArrayList<String> candidateList = new ArrayList<>();
    
     public static void main(String[] args) {
          Scanner scn = new Scanner(System.in);
        do {            
            System.out.println("\tPOWER Recruitment");
            System.out.println("\t------------------");
            System.out.println("1. Input New Candidate");
            System.out.println("2. View Candidate's Data");
            System.out.println("3. Remove Candidate");
            System.out.println("4. Exit");
            System.out.print("Choose: ");
            int choose = scn.nextInt();
            scn.nextLine();

            switch (choose) {
                case 1:
                    inputNewCandidate(scn);
                    break;
                case 2:
                    viewCandidateData();
                    break;
                case 3:
                    removeCandidate();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Exiting...");
                    break;
            }
            } while (true);
        }

        private static void inputNewCandidate(Scanner scn) {
            String name;
            String[] words;
            do {
                System.out.print("Input candidate's name: ");
                name = scn.nextLine();
                words = name.split(" ");

                if (!(name.length() >= 5 && name.length() <= 20)) {
                    System.out.println("Name must be between 5 and 20 characters");
                    continue;
                } else if ((name.endsWith(" ") || name.startsWith(" "))) {
                    System.out.println("The space character must not be in the first or last character");
                    continue;
                } else if (words.length < 2) {
                    System.out.println("Name must be at least 2 words!");
                    continue;
                }
                break;
            } while (true);

            String gender;
            do {
                System.out.print("Input candidate's gender [male | female]: ");
                gender = scn.nextLine();
            } while (!(gender.equals("male") || gender.equals("female")));

            String street;
            do {
                System.out.print("Input candidate's address [must be ended with 'street']: ");
                street = scn.nextLine();
            } while (!street.endsWith("street"));

            int age;
            do {
                System.out.print("Input candidate's age [17..30]: ");
                age = scn.nextInt();
            } while (!(age >= 17 && age <= 30));

            scn.nextLine(); 

            System.out.println("Thank you for registering. Your initials are: "
                    + Character.toUpperCase(words[0].charAt(0)) + Character.toUpperCase(words[1].charAt(0)));

            String candidateData =  name + ";" + gender + ";" + street + ";" + age;
            candidateList.add(candidateData);

            System.out.println("Thank you for registering. Your initials are: "
                    + Character.toUpperCase(words[0].charAt(0)) + Character.toUpperCase(words[1].charAt(0)));

            }

        private static void viewCandidateData() {
            System.out.println("Viewing Candidate's Data");
            if (candidateList.isEmpty()) {
                System.out.println("No Data!");
            } else {

                Collections.sort(candidateList, Comparator.naturalOrder());

                String [] data;
                for (String candidate : candidateList) {
                data = candidate.split(";");
                    System.out.print("nama" + data[0] + "\t"); 
                    System.out.print("gender" + data[1] + "\t");
                    System.out.print("street" + data[2] + "\t");
                    System.out.println("age" + data[3]);
                }
            }
        }

        private static void removeCandidate() {
            System.out.println("Removing candidate...");
           
        }

        }
    

